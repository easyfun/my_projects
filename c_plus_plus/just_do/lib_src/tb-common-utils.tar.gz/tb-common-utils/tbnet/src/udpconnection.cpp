/*
 * (C) 2007-2010 Taobao Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 * Version: $Id$
 *
 * Authors:
 *   duolong <duolong@taobao.com>
 *
 */

#include "tbnet.h"

namespace tbnet {

/*
 * ���캯��
 */
UDPConnection::UDPConnection(Socket *socket, IPacketStreamer *streamer,
                             IServerAdapter *serverAdapter) : Connection(socket, streamer, serverAdapter) {}

/*
 * ���캯��
 */
UDPConnection::~UDPConnection() {}

/*
 * д������
 *
 * @return �Ƿ�ɹ�
 */
bool UDPConnection::writeData() {
    return true;
}

/*
 * ��������
 *
 * @return ��������
 */
bool UDPConnection::readData() {
    return true;
}

}
